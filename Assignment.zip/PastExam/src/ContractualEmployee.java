class ContractualEmployee extends Employee {
    public ContractualEmployee(int employeeId, String firstName, String lastName, String dateOfBirth, int age, String department, int yearsOfExperience, double salary) {
        super(employeeId, firstName, lastName, dateOfBirth, age, department, yearsOfExperience, salary);
    }

    @Override
    public double calculatePension() {
        return salary * 0.02;
    }

    @Override
    public double calculateCBHI() {
        return 0;
    }

    @Override
    public double calculateMaternity() {
        return salary * 0.026;
    }
}